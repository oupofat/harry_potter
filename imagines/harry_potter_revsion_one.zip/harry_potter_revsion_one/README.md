This website was created by Kris Hays.
It is the first website he built when he started learning html and css in January of 2018.
